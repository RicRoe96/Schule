package mitarbeiter;

public enum Fuehrerscheinklasse {
    B,
    C,
    D
}
